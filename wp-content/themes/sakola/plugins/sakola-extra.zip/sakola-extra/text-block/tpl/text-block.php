<div class="sakola-text clearfix">
<?php 
	echo balancetags($custom_text);
?>
</div>